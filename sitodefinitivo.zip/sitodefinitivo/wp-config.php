<?php
// Begin AIOWPSEC Firewall
if (file_exists('C:/xampp4/htdocs/sitodefinitivo/aios-bootstrap.php')) {
	include_once('C:/xampp4/htdocs/sitodefinitivo/aios-bootstrap.php');
}
// End AIOWPSEC Firewall
/**
 * Il file base di configurazione di WordPress.
 *
 * Questo file viene utilizzato, durante l’installazione, dallo script
 * di creazione di wp-config.php. Non è necessario utilizzarlo solo via web
 * puoi copiare questo file in «wp-config.php» e riempire i valori corretti.
 *
 * Questo file definisce le seguenti configurazioni:
 *
 * * Impostazioni del database
 * * Chiavi segrete
 * * Prefisso della tabella
 * * ABSPATH
 *
 * * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Impostazioni database - È possibile ottenere queste informazioni dal proprio fornitore di hosting ** //
/** Il nome del database di WordPress */
define( 'DB_NAME', 'sitodefinitivo' );

/** Nome utente del database */
define( 'DB_USER', 'root' );

/** Password del database */
define( 'DB_PASSWORD', '' );

/** Hostname del database */
define( 'DB_HOST', 'localhost' );

/** Charset del Database da utilizzare nella creazione delle tabelle. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Il tipo di collazione del database. Da non modificare se non si ha idea di cosa sia. */
define( 'DB_COLLATE', '' );

/**#@+
 * Chiavi univoche di autenticazione e di sicurezza.
 *
 * Modificarle con frasi univoche differenti!
 * È possibile generare tali chiavi utilizzando {@link https://api.wordpress.org/secret-key/1.1/salt/ servizio di chiavi-segrete di WordPress.org}
 *
 * È possibile cambiare queste chiavi in qualsiasi momento, per invalidare tutti i cookie esistenti.
 * Ciò forzerà tutti gli utenti a effettuare nuovamente l'accesso.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         ')niysAgN[=KA^g1~VmiDO#|U?S0uK>O=`y6rMp{_~~}@6WEhp_Kt>f.x`%SlWZh%' );
define( 'SECURE_AUTH_KEY',  'AHJ9Iv;0w.f/2({2wneRQ}f+N+Q9D?(BZo~NGl@sRm%JRNduQ{ s86`Z}Y,S2`R`' );
define( 'LOGGED_IN_KEY',    '@dD!nHC<4zI6%YW,uJ,aCEg7ZyQ6Ps_%vW]*M/Mi071p#6P6_ bD)p|gA?uTnERU' );
define( 'NONCE_KEY',        'S?q14fs.7rfjPuVvxm/&Yg]CHvF/UMAku@$W)qZSS/RGL/-lznaI,Hcq)bD|!xGq' );
define( 'AUTH_SALT',        '@Ug<fu49]iB)(Cq3RcU}V?X@G3`S#Q|=ZI{zg)r3_0r({vf?,12NVve*/ET|GY>c' );
define( 'SECURE_AUTH_SALT', 'ikB=$)EbjjBZ{i-/7PfV#DR68+=w?(F[B#3mplFDez)Z+E_aF#5E;F>Ol^#-5cH$' );
define( 'LOGGED_IN_SALT',   'f_6O5Zg0IT/JON/Az;E:M4!NH}sp3-dy1agI*r#xn.`M[{6E,;e;-h}TXKIk&#z3' );
define( 'NONCE_SALT',       'w$j33Q ixKEm(r:#~7p3l8TT8T!|[hy74*CecwcBz4UE gO_6]@d-=QZ`FVG}eT^' );

/**#@-*/

/**
 * Prefisso tabella del database WordPress.
 *
 * È possibile avere installazioni multiple su di un unico database
 * fornendo a ciascuna installazione un prefisso univoco. Solo numeri, lettere e trattini bassi!
 */
$table_prefix = 'ossyl_';

/**
 * Per gli sviluppatori: modalità di debug di WordPress.
 *
 * Modificare questa voce a TRUE per abilitare la visualizzazione degli avvisi durante lo sviluppo
 * È fortemente raccomandato agli svilupaptori di temi e plugin di utilizare
 * WP_DEBUG all’interno dei loro ambienti di sviluppo.
 *
 * Per informazioni sulle altre costanti che possono essere utilizzate per il debug,
 * leggi la documentazione
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Aggiungere qualsiasi valore personalizzato tra questa riga e la riga "Finito, interrompere le modifiche". */



/* Finito, interrompere le modifiche! Buona pubblicazione. */

/** Path assoluto alla directory di WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Imposta le variabili di WordPress ed include i file. */
require_once ABSPATH . 'wp-settings.php';